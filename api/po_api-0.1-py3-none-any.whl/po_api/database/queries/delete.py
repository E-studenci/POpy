from po_api import DATABASE

## TODO: delete a path