

class DBConnectionError(ConnectionError):
    pass

