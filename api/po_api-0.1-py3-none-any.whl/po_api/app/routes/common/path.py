from po_api.app.response_parser import ResponseData, response_wrapper, ResponseError
from po_api import APP, BASIC_AUTH
from flask import jsonify, request

import po_api.utils.json_validation.json_schemas as schemas
import po_api.database.queries.read as read
import po_api.database.queries.create as create
import po_api.database.queries.update as update
import po_api.database.queries.delete as delete
import po_api.database.orm.models as models

PATH_PATH="/path"

@APP.route(f'{PATH_PATH}/get', methods=['GET'])
@BASIC_AUTH.login_required
@response_wrapper()
def get_all_paths():
    paths = read.get_all_paths()
    return ResponseData(
        code=200,
        data=jsonify(results=paths).response[0]
    )

@APP.route(f'{PATH_PATH}/get/<path_id>', methods=['GET'])
@BASIC_AUTH.login_required
@response_wrapper(schemas.EDIT_PATH_SCHEMA)
def get_path(path_id: int):
    result = read.get_path_by_id(path_id)
    if result:
        return ResponseData(
        code=200,
        data=jsonify(results=result)
        )
    return ResponseData(
        code=400,
        error = ResponseError(name="Invalid Data", description="path not found") )

@APP.route(f'{PATH_PATH}/get/from_waypoint/<waypoint_id>', methods=['GET'])
@BASIC_AUTH.login_required
@response_wrapper()
def get_paths_from_waypoint(waypoint_id: int):
    result = read.get_all_paths(False, waypoint_id)
    if result:
        return ResponseData(
        code=200,
        data=jsonify(results=result)
        )
    return ResponseData(
        code=400,
        error = ResponseError(name="Invalid Data", description="waypoint not found") )


@APP.route(f'{PATH_PATH}/create', methods=['PUT'])
@BASIC_AUTH.login_required
@response_wrapper(schemas.CREATE_PATH_SCHEMA)
def create_path():
    json_data = request.json
    result = create.create_path(json_data)
    if isinstance(result, str):
         return ResponseData(
            code = 400,
            error = ResponseError(name="Invalid Data", description=result)
        )
    return ResponseData(
        code=200
    )

@APP.route(f'{PATH_PATH}/edit/<path_id>', methods=['PATCH'])
@BASIC_AUTH.login_required
@response_wrapper(schemas.EDIT_PATH_SCHEMA)
def edit_path(path_id: int):
    json_data = request.json
    result = update.update_path(path_id, json_data)
    if isinstance(result, str):
         return ResponseData(
            code = 400,
            error = ResponseError(name="Invalid Data", description=result)
        )
    if result.rowcount == 0:
        return ResponseData(
            code = 400,
            error = ResponseError(name="Invalid Data", description="Path not found")
        )
    return ResponseData(
        code=200
    )

@APP.route(f'{PATH_PATH}/delete/<path_id>', methods=['PATCH'])
@BASIC_AUTH.login_required
@response_wrapper()
def delete_path(path_id: int):
    result = update.update_path(path_id, {"status": models.PathStatus.closed})
    if isinstance(result, str):
         return ResponseData(
            code = 400,
            error = ResponseError(name="Invalid Data", description=result)
        )
    if result.rowcount == 0:
        return ResponseData(
            code = 400,
            error = ResponseError(name="Invalid Data", description="Path not found")
        )
    return ResponseData(
        code=200
    )